# MeteorGuard

A Paper 1.21.x anti-cheat / anti-ESP plugin focused on freecam, xray and client-mod abuse, with low overhead.

## Features

- **AntiFreecam (always on, no switch)** - surface players get deepslate where the deep caves are, players underground get stone where the surface is. Mobs, items and armor stands inside the hidden area are hidden too. Built on PacketEvents.
- **Anti-ESP** - players behind walls are hidden (they stay in the tab list); chests, spawners, furnaces, shulkers... are hidden from far-away players.
- **Stash-entity hiding** - dropped items, item frames, chest minecarts and armor stands behind walls are hidden (item/stash ESP).
- **Anti plugin-scan** - `/pl`, `/ver`, namespaced commands and tab-complete scans (Meteor Client) see nothing; `/meteor` itself looks like an unknown command to players without permission.
- **Client checks** - blocked cheat-client brands (alert or kick) and "vanilla" brands that registered Fabric/Forge channels.
- Join protection (bot/IP limits, attack mode, verification), rate limits, illegal item scanning, ore-ratio alerts, auto-clicker and build-macro checks, GrimAC link, staff alerts with log files.

## Requirements

- Paper or Purpur 1.21.x, Java 21
- **PacketEvents 2.13.0+** plugin (required - AntiFreecam needs it)
- Optional: GrimAC, LuckPerms, Floodgate. ProtocolLib is not needed by this plugin.

## Commands

`/meteor` (aliases `/meteorguard`, `/antiesp`, `/shield`)

| Command | What it does |
|---|---|
| `/meteor control` | live control room GUI |
| `/meteor status` | anti-ESP status |
| `/meteor antifreecam` | AntiFreecam status (always on) |
| `/meteor antifreecam bypass [player]` | toggle bypass for a player |
| `/meteor antifreecam refresh [player]` | re-check the layer and re-send chunks |
| `/meteor reload` | reload config.yml |
| `/meteor toggle` | turn anti-ESP on/off (AntiFreecam stays on) |
| `/meteor alerts` | toggle your staff alerts |
| `/meteor attack [on/off]` | force join-attack mode |
| `/meteor scan <player>` | scan a player's items |

## Building

```
gradle build
```
The jar is in `build/libs/`.
