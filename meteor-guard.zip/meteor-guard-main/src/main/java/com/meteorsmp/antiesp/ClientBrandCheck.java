package com.meteorsmp.antiesp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Looks at the client brand a few seconds after join: blocked cheat clients and spoofed "vanilla" brands. */
public final class ClientBrandCheck implements Listener {

    private final AntiESPPlugin plugin;
    private final AlertManager alerts;

    private boolean enabled = true, alertNonVanilla, detectSpoof = true, kick;
    private long delay = 60L;
    private String kickMessage = "&cThat client is not allowed on this server.";
    private String bedrockPrefix = ".";
    private final List<String> blocked = new ArrayList<>();

    public ClientBrandCheck(AntiESPPlugin plugin, AlertManager alerts) {
        this.plugin = plugin;
        this.alerts = alerts;
    }

    public void reload() {
        var c = plugin.getConfig();
        String p = "client-checks.brand.";
        enabled = c.getBoolean(p + "enabled", true);
        delay = Math.max(20, c.getInt(p + "check-delay-ticks", 60));
        kick = "kick".equalsIgnoreCase(c.getString(p + "action", "alert"));
        kickMessage = c.getString(p + "kick-message", kickMessage);
        alertNonVanilla = c.getBoolean(p + "alert-non-vanilla", false);
        detectSpoof = c.getBoolean(p + "detect-spoof", true);
        bedrockPrefix = c.getString("join-protection.bedrock-prefix", ".");
        blocked.clear();
        for (String s : c.getStringList(p + "blocked-brands")) blocked.add(s.toLowerCase(Locale.ROOT));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!enabled) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> check(p), delay);
    }

    private void check(Player p) {
        if (!enabled || !p.isOnline() || plugin.hasBypass(p)) return;
        if (bedrockPrefix != null && !bedrockPrefix.isEmpty() && p.getName().startsWith(bedrockPrefix)) return;

        String brand = p.getClientBrandName();
        if (brand == null || brand.isBlank()) return;
        String b = brand.toLowerCase(Locale.ROOT);

        for (String bad : blocked) {
            if (b.contains(bad)) {
                alerts.alert("CLIENT-BRAND", p.getName(), "blocked client \"" + brand + "\"");
                if (kick) p.kick(AlertManager.c(kickMessage));
                return;
            }
        }

        if (detectSpoof && b.equals("vanilla")) {
            for (String ch : p.getListeningPluginChannels()) {
                String lc = ch.toLowerCase(Locale.ROOT);
                if (lc.startsWith("fabric") || lc.startsWith("fml:") || lc.startsWith("forge")
                        || lc.startsWith("neoforge") || lc.startsWith("quilt")) {
                    alerts.alert("BRAND-SPOOF", p.getName(), "says vanilla but registered " + ch);
                    return;
                }
            }
        }

        if (alertNonVanilla && !b.equals("vanilla")) {
            alerts.alert("CLIENT-BRAND", p.getName(), "brand: " + brand);
        }
    }
}
