package com.meteorsmp.antiesp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Remembers WHY each entity is hidden from each player, so two systems (depth mask and
 * line-of-sight hiding) never un-hide each other's work. Main thread only.
 */
final class EntityVisibility {

    private final AntiESPPlugin plugin;
    private final Map<UUID, Map<UUID, Set<String>>> state = new HashMap<>();

    EntityVisibility(AntiESPPlugin plugin) {
        this.plugin = plugin;
    }

    void hide(Player viewer, Entity target, String reason) {
        Map<UUID, Set<String>> m = state.computeIfAbsent(viewer.getUniqueId(), k -> new HashMap<>());
        Set<String> reasons = m.computeIfAbsent(target.getUniqueId(), k -> new HashSet<>());
        reasons.add(reason);
        // canSee() makes this self-healing if the server forgot the hide (entity unloaded and came back)
        if (viewer.canSee(target)) viewer.hideEntity(plugin, target);
    }

    void show(Player viewer, Entity target, String reason) {
        Map<UUID, Set<String>> m = state.get(viewer.getUniqueId());
        if (m == null) return;
        Set<String> reasons = m.get(target.getUniqueId());
        if (reasons == null || !reasons.remove(reason)) return;
        if (reasons.isEmpty()) {
            m.remove(target.getUniqueId());
            if (!viewer.canSee(target)) viewer.showEntity(plugin, target);
        }
    }

    /** Entities currently hidden from this viewer for this reason. */
    List<UUID> hiddenFor(Player viewer, String reason) {
        List<UUID> out = new ArrayList<>();
        Map<UUID, Set<String>> m = state.get(viewer.getUniqueId());
        if (m == null) return out;
        for (Map.Entry<UUID, Set<String>> en : m.entrySet()) {
            if (en.getValue().contains(reason)) out.add(en.getKey());
        }
        return out;
    }

    /** Show everything hidden for this reason. Entities that no longer exist are just forgotten. */
    void clearReason(Player viewer, String reason) {
        for (UUID id : hiddenFor(viewer, reason)) {
            Entity e = Bukkit.getEntity(id);
            if (e != null && e.isValid()) {
                show(viewer, e, reason);
            } else {
                Map<UUID, Set<String>> m = state.get(viewer.getUniqueId());
                if (m == null) continue;
                Set<String> reasons = m.get(id);
                if (reasons != null) {
                    reasons.remove(reason);
                    if (reasons.isEmpty()) m.remove(id);
                }
            }
        }
    }

    /** Drops bookkeeping for entities that died or despawned (keeps memory flat). */
    void prune(Player viewer) {
        Map<UUID, Set<String>> m = state.get(viewer.getUniqueId());
        if (m == null || m.isEmpty()) return;
        m.keySet().removeIf(id -> {
            Entity e = Bukkit.getEntity(id);
            return e != null && !e.isValid();
        });
        if (m.size() > 4000) m.keySet().removeIf(id -> Bukkit.getEntity(id) == null);
    }

    void forget(UUID viewer) {
        state.remove(viewer);
    }

    int total() {
        int n = 0;
        for (Map<UUID, Set<String>> m : state.values()) n += m.size();
        return n;
    }

    void clearAll() {
        for (Map.Entry<UUID, Map<UUID, Set<String>>> en : state.entrySet()) {
            Player v = Bukkit.getPlayer(en.getKey());
            if (v == null) continue;
            for (UUID eid : en.getValue().keySet()) {
                Entity e = Bukkit.getEntity(eid);
                if (e != null && e.isValid() && !v.canSee(e)) v.showEntity(plugin, e);
            }
        }
        state.clear();
    }
}
