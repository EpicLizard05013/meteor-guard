package com.meteorsmp.antiesp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Entity-side protection:
 *  - DEPTH: mobs / items / armor stands in the area the depth mask hides are hidden too, so a freecam
 *    player at the surface can't see mobs in deep caves (and the other way around).
 *  - LOS: stash-type entities (dropped items, item frames, chest minecarts ...) behind walls are hidden,
 *    so item/stash ESP has nothing to draw. Players are handled by the main anti-ESP pass, not here.
 */
final class EntityShield implements Listener {

    static final String DEPTH = "depth";
    static final String LOS = "los";

    private final AntiESPPlugin plugin;
    private final DepthMask depth; // may be null if PacketEvents failed to start
    private final EntityVisibility vis;
    private BukkitTask task;
    private boolean warned;

    private boolean depthEntities, losEnabled;
    private int interval = 10, maxEntities = 400;
    private double range = 64.0, losMin = 10.0;
    private final Set<EntityType> losTypes = EnumSet.noneOf(EntityType.class);

    EntityShield(AntiESPPlugin plugin, DepthMask depth) {
        this.plugin = plugin;
        this.depth = depth;
        this.vis = new EntityVisibility(plugin);
    }

    void start() {
        reload();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        schedule();
    }

    void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        HandlerList.unregisterAll(this);
        vis.clearAll();
    }

    void reload() {
        var c = plugin.getConfig();
        depthEntities = c.getBoolean("antifreecam.hide-entities", true);
        losEnabled = c.getBoolean("entity-hiding.enabled", true);
        range = Math.max(16.0, c.getDouble("entity-hiding.range", 64.0));
        losMin = Math.max(0.0, c.getDouble("entity-hiding.min-distance", 10.0));
        maxEntities = Math.max(50, c.getInt("entity-hiding.max-entities-per-player", 400));
        interval = Math.max(2, c.getInt("entity-hiding.check-interval", 10));
        losTypes.clear();
        for (String s : c.getStringList("entity-hiding.types")) {
            try {
                losTypes.add(EntityType.valueOf(s.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Unknown entity type in entity-hiding.types: " + s);
            }
        }
        if (task != null) {
            task.cancel();
            schedule();
        }
    }

    int hiddenCount() {
        return vis.total();
    }

    private void schedule() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, interval);
    }

    private void tick() {
        boolean active = plugin.isActive();
        for (Player p : Bukkit.getOnlinePlayers()) {
            try {
                process(p, active);
            } catch (RuntimeException ex) {
                if (!warned) {
                    warned = true;
                    plugin.getLogger().warning("EntityShield error (shown once): " + ex);
                }
            }
        }
    }

    private void process(Player p, boolean active) {
        boolean doDepth = depthEntities && depth != null;
        boolean doLos = losEnabled && active && !losTypes.isEmpty()
                && !plugin.hasBypass(p)
                && p.getGameMode() != GameMode.SPECTATOR
                && plugin.isEspWorld(p.getWorld());

        if (!doDepth) vis.clearReason(p, EntityShield.DEPTH);
        if (!doLos) vis.clearReason(p, EntityShield.LOS);
        if (!doDepth && !doLos) return;

        UUID pid = p.getUniqueId();
        Entity vehicle = p.getVehicle();
        UUID vehicleId = vehicle == null ? null : vehicle.getUniqueId();
        Location eye = p.getEyeLocation();

        List<Entity> near = p.getNearbyEntities(range, 384.0, range);
        int n = 0;
        for (Entity e : near) {
            if (e instanceof Player) continue;
            if (++n > maxEntities) break;
            if (e.getUniqueId().equals(vehicleId)) continue;
            if (e instanceof LivingEntity le && le.isLeashed() && p.equals(le.getLeashHolder())) continue;

            Location loc = e.getLocation();

            boolean depthHide = doDepth && depth.isEntityMasked(pid, loc.getBlockY());
            if (depthHide) vis.hide(p, e, EntityShield.DEPTH);
            else vis.show(p, e, EntityShield.DEPTH);

            boolean losHide = false;
            if (doLos && !depthHide && losTypes.contains(e.getType())) {
                double d2 = loc.distanceSquared(eye);
                if (d2 >= losMin * losMin && d2 <= range * range) {
                    losHide = plugin.losBlocked(eye, loc);
                }
            }
            if (losHide) vis.hide(p, e, EntityShield.LOS);
            else vis.show(p, e, EntityShield.LOS);
        }
        vis.prune(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        vis.forget(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        vis.forget(e.getPlayer().getUniqueId());
    }
}
